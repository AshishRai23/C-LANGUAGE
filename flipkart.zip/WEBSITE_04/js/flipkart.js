function validate() {
    var user = document.getElementById('user').value;
    var pass = document.getElementById('pass').value;

    if (user == "") {
        document.getElementById('userspan').innerHTML = "**Please Enter Your Name";
        return false;
    }
    if ((user.length < 2) || (user.length > 20)) {
        document.getElementById('userspan').innerHTML = "**Character must be between 2 and 20";
        return false;
    }
    if (!isNaN(user)) {
        document.getElementById('userspan').innerHTML = "** User name not valid";
        return false;
    }
    if (pass == "") {
        document.getElementById('passspan').innerHTML = "**Please Enter Your Password";
        return false;
    }
    if ((pass.length < 2) || (pass.length > 15)) {
        document.getElementById('passspan').innerHTML = "**Password must be between 2 and 15";
        return false;
    }
}

var dt;
var h;
var m;
var s;
setInterval(()=>{
    dt = new Date();
    h = dt.getHours();
    m = dt.getMinutes();
    s = dt.getSeconds();
    if(h == 0){
        h = 12;
    }
    if(h > 12){
        h = h - 12;
    }
    if(h < 10){
        h = '0' + h;
    }
    if(m < 10){
        m = '0' + m;
    }
    if(s < 10){
        s = '0' + s;
    }

    let time = h + ':' + m + ':' + s; 
    a = document.getElementById('digcl').innerText = time;
    // document.getElementById('mcd').innerContent = time;

}, 1000);

// let dt;
// let h;
// let m;
// let s;

// setInterval(()=>{
//     dt = new Date();
//     h = dt.getHours();
//     m
// },1000)